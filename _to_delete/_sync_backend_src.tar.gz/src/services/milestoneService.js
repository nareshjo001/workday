const { pool } = require("../config/db");
const milestoneRepository = require("../repositories/milestoneRepository");
const timesheetRepository = require("../repositories/timesheetRepository");
const contractorRepository = require("../repositories/contractorRepository");
const billingService = require("./billingService");
const invoiceService = require("./invoiceService");

/**
 * Module 5 integration boundary — PROJECT-LEVEL REDESIGN.
 *
 * This is the ONLY place Module 4 talks to milestone/billing concerns —
 * timesheetService (Module 4) knows the single fact "a timesheet was
 * just approved, go ask the milestone module to evaluate this project",
 * and nothing more. No milestone/billing business logic lives in Module
 * 4 — that is entirely Module 5's responsibility, implemented behind
 * `checkAndTriggerMilestones(projectId)`, the ONE reusable function the
 * spec requires: called after every timesheet approval AND after a PM
 * creates a new milestone (same two call sites the old per-contractor
 * `evaluateMilestonesForContractorProject` had — this function replaces
 * it entirely, there is no parallel/duplicated milestone-detection logic
 * anywhere else in this codebase).
 *
 * THE MODEL: a milestone is a project-wide cumulative-APPROVED-hours
 * checkpoint, contributed to by however many different contractors are
 * staffed on the project — never a single contractor's own total. When a
 * milestone's threshold is crossed, this function must determine, from
 * ACTUAL approved timesheet data, exactly which contractors contributed
 * how many hours WITHIN THAT SPECIFIC THRESHOLD INTERVAL (previous
 * threshold boundary -> this threshold), never an even/equal split, and
 * never re-billing hours already billed at a prior milestone. See
 * apportionContributions below for the algorithm.
 */

/**
 * Walks every APPROVED timesheet for a project, in the exact
 * chronological order their hours became part of the project's
 * cumulative approved total (see
 * timesheetRepository.listApprovedOrderedForProject), and splits each
 * row's hours across the interval [intervalStart, intervalEnd) by
 * tracking a running cumulative position.
 *
 * Worked example straight from the spec: a project sits at 45h, a
 * contractor submits and gets approved for 10h, taking the cumulative
 * total to 55h; M1's threshold is 50h. This function is called with
 * intervalStart=0 (no milestone MET yet) and intervalEnd=50 for M1. As it
 * walks the ordered rows, the row that pushes cumulative from 45 -> 55
 * has rowStart=45, rowEnd=55; its overlap with [0,50) is [45,50) = 5
 * hours, so only 5 of that row's 10 hours are attributed to M1. The
 * remaining 5 hours (the [50,55) portion) are simply not part of this
 * interval — they are never discarded or double-counted, they are just
 * left where they are: the NEXT time this function runs for the NEXT
 * pending milestone (say M2 at 100h), intervalStart will be 50 (M1's own
 * threshold, once MET) and the SAME row will be walked again from
 * scratch, this time contributing its [50,55) portion to M2's interval.
 * No state about "leftover" hours is ever persisted — it is correctly
 * re-derived every call from the full ordered row list plus whichever
 * thresholds are already MET.
 *
 * A single row can also single-handedly cross MULTIPLE thresholds if
 * enough hours are approved in one shot (spec CASE 3: 45h -> one 10h
 * approval -> 155h, with M1=50/M2=100/M3=150 all in the same call) —
 * this works because the caller (checkAndTriggerMilestones) invokes this
 * function once per pending milestone, in ascending threshold order,
 * advancing intervalStart to each milestone's own threshold right after
 * marking it MET, so the same underlying row list is simply re-walked
 * (cheap at this MVP's scale) for each interval in turn.
 *
 * Returns a Map<contractorId, hoursInThisInterval> containing only
 * contractors with a strictly positive apportioned amount — a contractor
 * who contributed nothing to this specific interval gets no row at all
 * (no zero-hour contribution/billing/invoice is ever created).
 */
function apportionContributions(orderedApprovedRows, intervalStart, intervalEnd) {
  const contributions = new Map();
  let cumulative = 0;

  for (const row of orderedApprovedRows) {
    const rowStart = cumulative;
    const rowEnd = cumulative + row.hours_logged;
    cumulative = rowEnd;

    const overlapStart = Math.max(rowStart, intervalStart);
    const overlapEnd = Math.min(rowEnd, intervalEnd);
    if (overlapEnd > overlapStart) {
      const hours = overlapEnd - overlapStart;
      contributions.set(row.contractor_id, (contributions.get(row.contractor_id) || 0) + hours);
    }
  }

  return contributions;
}

/**
 * The real milestone-detection + billing entry point, called both:
 *   1. After every timesheet approval (via checkAndTriggerMilestones —
 *      same function, this IS the reusable hook, not a wrapper around a
 *      differently-named one).
 *   2. Immediately after a PM creates a new milestone (via
 *      pmMilestoneService), so a milestone created retroactively below
 *      the project's already-approved hours is caught and billed right
 *      away instead of silently waiting for the next approved timesheet.
 *
 * One transaction, covering the detection + billing steps below; the
 * Module 6 invoice-generation hook runs AFTER commit, once per
 * newly-created contribution, each wrapped in its own try/catch so a
 * failure there can never affect anything already committed:
 *
 *   1. Lock the project row and every PENDING milestone for it
 *      (`SELECT ... FOR UPDATE`) — the actual concurrency guarantee: a
 *      second, concurrent evaluation for the SAME project blocks here
 *      until this transaction commits or rolls back, so it can never
 *      double-process the same milestone or double-count the same hours.
 *   2. Read every APPROVED timesheet for the project, in chronological
 *      order, freshly inside this transaction (never trusted from any
 *      caller) — see timesheetRepository.listApprovedOrderedForProject.
 *   3. For every locked PENDING milestone, ascending by threshold: if the
 *      project's total approved hours haven't reached this threshold yet,
 *      skip it (and keep checking the rest — thresholds are not
 *      guaranteed to have been created in ascending order, even though
 *      that's the expected usage). Otherwise, apportion the
 *      [previousBoundary, thisThreshold) interval across contractors
 *      (apportionContributions above), mark the milestone MET, and write
 *      one immutable contribution/billing row per contributing
 *      contractor — each contractor's hourly_rate is read from
 *      contractors.hourly_rate INSIDE this transaction (row-locked via
 *      findByIdForUpdate), never from any request payload. previousBoundary
 *      then advances to this milestone's own threshold for the next
 *      iteration, so a single call can correctly process several
 *      thresholds crossed at once (spec CASE 3).
 *   4. COMMIT. Then, outside the transaction, invoke the Module 6 hook
 *      once per newly-created contribution row.
 *
 * This function deliberately never throws — a failure here must never
 * surface as a failure of whatever triggered it (a successful timesheet
 * approval, or a successful milestone creation). Errors are logged and
 * swallowed; see the try/catch below.
 */
async function checkAndTriggerMilestones(projectId) {
  const conn = await pool.getConnection();
  let newlyCreatedContributions = [];
  try {
    await conn.beginTransaction();

    const pending = await milestoneRepository.lockPendingForProject(conn, projectId);
    if (pending.length === 0) {
      await conn.commit();
      return;
    }

    const orderedApprovedRows = await timesheetRepository.listApprovedOrderedForProject(conn, projectId);
    const totalApprovedHours = orderedApprovedRows.reduce((sum, r) => sum + r.hours_logged, 0);

    let previousBoundary = await milestoneRepository.maxMetThresholdForProject(conn, projectId);
    // Row-lock cache: a contractor's hourly_rate must be read (and locked)
    // at most once per call even if they contribute to several milestones
    // crossed in the same evaluation, and must be locked fresh every call
    // (never cached across separate checkAndTriggerMilestones invocations).
    const lockedContractors = new Map();

    for (const milestone of pending) {
      const threshold = Number(milestone.threshold_hours);
      if (totalApprovedHours < threshold) continue; // Not reached yet — keep checking the rest.

      const intervalStart = Math.max(previousBoundary, 0);
      const contributions = apportionContributions(orderedApprovedRows, intervalStart, threshold);

      const marked = await milestoneRepository.markMet(conn, milestone.id);
      if (!marked) {
        // Lost an (unreachable, under this row lock) race — skip, not an
        // error. Still advance the boundary so downstream milestones in
        // this same loop are computed against the correct interval.
        previousBoundary = threshold;
        continue;
      }

      for (const [contractorId, hours] of contributions) {
        if (hours <= 0) continue;

        let contractor = lockedContractors.get(contractorId);
        if (!contractor) {
          contractor = await contractorRepository.findByIdForUpdate(conn, contractorId);
          if (!contractor) continue; // Defensive — should be unreachable.
          lockedContractors.set(contractorId, contractor);
        }

        const billing = await billingService.createBillingRecord(conn, {
          milestoneId: milestone.id,
          contractorId,
          approvedHours: hours,
          hourlyRate: contractor.hourly_rate,
        });
        // billing is null only if a contribution row already existed
        // (ER_DUP_ENTRY) — unreachable under the row lock held for this
        // transaction, but createBillingRecord treats it as "already
        // billed" rather than an error either way.
        if (billing) {
          newlyCreatedContributions.push({ milestoneId: milestone.id, ...billing });
        }
      }

      previousBoundary = threshold;
    }

    await conn.commit();
  } catch (err) {
    await conn.rollback().catch(() => {});
    // Never propagate — see this function's own doc comment above for
    // why. The timesheet approval (or milestone creation) that triggered
    // this already succeeded and must not appear to have failed.
    console.error(`[milestoneService] checkAndTriggerMilestones failed for project ${projectId}:`, err);
    return;
  } finally {
    conn.release();
  }

  // Module 6 boundary — called only after every newly-MET milestone's
  // contribution rows are safely committed. A failure here must never
  // undo either. `billingId` (the milestone_billings row's own id) is
  // what invoiceService actually anchors the invoice to.
  for (const contribution of newlyCreatedContributions) {
    try {
      await invoiceService.generateInvoiceForMilestone({
        milestoneBillingId: contribution.billingId,
        milestoneId: contribution.milestoneId,
        projectId,
        contractorId: contribution.contractorId,
        billingAmount: contribution.billingAmount,
      });
    } catch (err) {
      console.error(
        `[milestoneService] invoiceService.generateInvoiceForMilestone failed for milestone ${contribution.milestoneId}, contractor ${contribution.contractorId}:`,
        err
      );
    }
  }
}

module.exports = {
  checkAndTriggerMilestones,
  // Exported for unit-level testing of the apportionment math in
  // isolation (spec CASE 1/2/3) without needing a full DB transaction.
  apportionContributions,
};
