const ApiError = require("../utils/ApiError");

function parsePositiveInt(value) {
  const n = Number(value);
  return Number.isInteger(n) && n > 0 ? n : null;
}

/**
 * allocatedHours must be a finite, positive number with at most 2
 * decimal places — matches project_assignments.allocated_hours
 * DECIMAL(9,2), same precision convention as every other hours field in
 * this codebase (timesheets.hours_logged, milestones.threshold_hours).
 */
function parseAllocatedHours(value, errors, index) {
  const raw = typeof value === "number" || typeof value === "string" ? value : NaN;
  const hours = Number(raw);
  if (raw === "" || !Number.isFinite(hours) || hours <= 0) {
    errors.push(`assignments[${index}].allocatedHours must be a positive number.`);
    return null;
  }
  if (Math.round(hours * 100) !== hours * 100) {
    errors.push(`assignments[${index}].allocatedHours may have at most 2 decimal places.`);
    return null;
  }
  return hours;
}

/**
 * Validates the URL params + body for
 * POST /api/vendor/projects/:projectId/requirements/:requirementId/assign.
 * Returns { projectId, requirementId, assignments: [{contractorId, allocatedHours}] }
 * on success, throws ApiError(400) otherwise.
 *
 * PROJECT HOURS/ALLOCATION REDESIGN: the body shape changed from a flat
 * `contractorIds: number[]` array to `assignments: {contractorId,
 * allocatedHours}[]` — every contractor being assigned in this batch now
 * also declares how many of the project's expected_hours they're being
 * staffed for, which vendorAssignmentService validates transactionally
 * against the project's remaining capacity. This is the same existing
 * endpoint extended, not a new one (per the redesign's "don't add
 * unnecessary new endpoints" instruction).
 *
 * Deliberately does NOT accept vendor_id or pm ownership from the body —
 * the assigning vendor is always derived server-side from the
 * authenticated JWT (see vendorAssignmentService.assignContractors), and
 * project/requirement ownership is re-verified in the service, not
 * trusted from params alone.
 */
function validateAssignContractors(params = {}, body = {}) {
  const errors = [];

  const projectId = parsePositiveInt(params.id);
  const requirementId = parsePositiveInt(params.requirementId);

  if (!projectId) errors.push("projectId must be a positive integer.");
  if (!requirementId) errors.push("requirementId must be a positive integer.");

  const assignmentsInput = Array.isArray(body.assignments) ? body.assignments : null;
  const assignments = [];
  const seenContractorIds = new Set();
  if (!assignmentsInput || assignmentsInput.length === 0) {
    errors.push("assignments is required and must be a non-empty array.");
  } else {
    assignmentsInput.forEach((entry, index) => {
      if (typeof entry !== "object" || entry === null) {
        errors.push(`assignments[${index}] must be an object.`);
        return;
      }
      const contractorId = parsePositiveInt(entry.contractorId);
      if (!contractorId) {
        errors.push(`assignments[${index}].contractorId must be a positive integer.`);
      } else if (seenContractorIds.has(contractorId)) {
        errors.push(`assignments contains duplicate contractorId ${contractorId}.`);
      }

      const allocatedHours = parseAllocatedHours(entry.allocatedHours, errors, index);

      if (contractorId && allocatedHours !== null) {
        seenContractorIds.add(contractorId);
        assignments.push({ contractorId, allocatedHours });
      }
    });
  }

  if (errors.length > 0) {
    throw ApiError.badRequest("Validation failed", errors);
  }

  return { projectId, requirementId, assignments };
}

module.exports = { validateAssignContractors };
