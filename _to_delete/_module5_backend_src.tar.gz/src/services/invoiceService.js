/**
 * Module 6 integration boundary — the mirror of milestoneService.js's own
 * comment at the top of that file. This is the ONLY place Module 5 talks
 * to invoicing concerns: once billingService has recorded an immutable
 * billing snapshot for a newly-MET milestone, milestoneService calls this
 * single function and nothing more. No invoice-generation, PDF, ledger,
 * or payment logic lives in Module 5 — that is entirely Module 6's
 * responsibility, implemented behind this same function signature so
 * Module 5 never has to change when Module 6 lands.
 *
 * For MVP this is a deliberate no-op placeholder — it exists so the call
 * site (milestoneService, right after a milestone's MET transition +
 * billing snapshot have both committed) is wired up, real, and easy to
 * find — not so it does anything yet. Do NOT add invoice/ledger/payment
 * logic here; add it in a real Module 6 invoice module and have this
 * function delegate to it.
 *
 * Called AFTER the milestone's transaction (MET transition + billing
 * insert) has committed, and the caller wraps this call in its own
 * try/catch — a failure or throw here must never undo the timesheet
 * approval, the milestone's MET status, or its billing record, all of
 * which are already safely persisted by the time this runs.
 */

/**
 * @param {object} params
 * @param {number} params.milestoneId - The milestone that was just marked MET.
 * @param {number} params.projectId - The project the milestone belongs to.
 * @param {number} params.contractorId - The contractor the milestone/billing belongs to.
 * @param {number} params.billingAmount - The immutable billing_amount just recorded.
 * @returns {Promise<void>}
 */
async function generateInvoiceForMilestone({ milestoneId, projectId, contractorId, billingAmount }) {
  // Intentionally a no-op for the Module 5 MVP. Module 6 replaces this
  // body with real invoice generation; the call site never needs to
  // change.
  return null;
}

module.exports = { generateInvoiceForMilestone };
