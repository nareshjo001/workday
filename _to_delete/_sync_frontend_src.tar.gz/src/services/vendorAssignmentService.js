import apiClient from "./apiClient";

/**
 * Vendor's project-assignment API. Replaces the old single-contractor
 * POST /vendor/assignments endpoint (Module 3 revision) with the
 * vendor-centric workflow revision's atomic multi-contractor assign:
 * one request assigns every selected contractor to one requirement in a
 * single all-or-nothing transaction.
 *
 * PROJECT HOURS/ALLOCATION REDESIGN: `assignments` is now
 * `[{contractorId, allocatedHours}, ...]` instead of a flat
 * `contractorIds` array — every contractor being staffed in this batch
 * also declares how many of the project's expected_hours they're taking
 * on, checked transactionally server-side against remaining capacity
 * (see vendorAssignmentService.assignContractors on the backend).
 */
async function assignContractors(projectId, requirementId, assignments) {
  const { data } = await apiClient.post(
    `/vendor/projects/${projectId}/requirements/${requirementId}/assign`,
    { assignments }
  );
  return data;
}

export default { assignContractors };
